CTITRIAGE v3 controlled prompt-injection experiment
Created 2026-10-04T15:43:18.269956+00:00
Benchmark: 360 frozen synthetic CTI cases (120 per family), sha256 de8dff91fb540d27ba8e2dbfdebb280d50091810487c59865cdc3e179ae5ac1a
Cases actually run: 360 (120 per family; see benchmark/active_subset.json)
Models attempted: [["Qwen3-4B", "Qwen/Qwen3-4B-Instruct-2507"], ["Phi-4-mini", "microsoft/Phi-4-mini-instruct"], ["Qwen2.5-3B", "Qwen/Qwen2.5-3B-Instruct"], ["Granite-3.3-2B", "ibm-granite/granite-3.3-2b-instruct"]]
Primary decoding: greedy, max_new_tokens=160, fp16 (see model_mode column for any 4-bit fallback)
This is a NEW benchmark. Do not pool with the v2 (36-case) results.
Files: raw/rows.jsonl (every raw output + scores), statistics/*.csv, tables/*.tex, figures/*.png,
PREREGISTRATION.md (hypotheses and tests written before any output), benchmark/ (frozen cases, prompts, hash).
Coverage per model and tier is in statistics/coverage.csv: report only complete models for main claims.
